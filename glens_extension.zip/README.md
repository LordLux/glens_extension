# Search with Google Lens

A tiny extension that adds a context-menu item to search any image with Google Lens.

## What it does

- Adds a "Search with Google Lens" item when you right-click an image.
- Opens Google Lens in a new tab using the image URL.

## Usage

Right-click any image and choose "Search with Google Lens" from the context menu.
